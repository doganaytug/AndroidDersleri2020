package com.tugbadogan.resimuygulamasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView ivResim;
    TextView   tvBaslik;
    Button btnIleri,btnGeri,btnRastgele;

    int sayi=0;
    ArrayList<Resim> resimler= new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivResim=findViewById(R.id.ivResim);
        tvBaslik=findViewById(R.id.tvBaslik);
        btnGeri=findViewById(R.id.btnGeri);
        btnIleri=findViewById(R.id.btnIleri);
        btnRastgele=findViewById(R.id.btnRastgele);

        //(int id, String resimBaslik, int resim
        resimler.add (new Resim(1,"resimBaslik",R.drawable.images));
        resimler.add (new Resim(1,"resimBaslik",R.drawable.images1));
        resimler.add (new Resim(1,"resimBaslik",R.drawable.images3));
        resimler.add (new Resim(1,"resimBaslik",R.drawable.images4));
        resimler.add (new Resim(1,"resimBaslik",R.drawable.images5));
        resimler.add (new Resim(1,"resimBaslik",R.drawable.images6));

        ivResim.setImageResource(resimler.get(0).getResim());
        tvBaslik.setText(resimler.get(0).getResimBaslik());//


        btnRastgele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Random rnd=new Random();
                sayi=rnd.nextInt(resimler.size());
                ivResim.setImageResource(resimler.get(sayi).getResim());
                tvBaslik.setText(resimler.get(sayi).getResimBaslik());//kod ile text nesnesinin görünen yazısını değiştirir.

            }
        });
       btnGeri.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        if (sayi!)=0){
           sayi--;
            ivResim.setImageResource(resimler.get(sayi).getResim());
            tvBaslik.setText();//kod ile text nesnesinin görünen yazısını değiştirir.
        }
    }
});

      btnIleri.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if(sayi<resimler.size()-1)
            sayi++;
        ivResim.setImageResource(resimler.get(sayi).getResim());
        tvBaslik.setText();//kod ile text nesnesinin görünen yazısını değiştirir.

    }
});

    }
}
